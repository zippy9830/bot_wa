apt update
apt upgrade
apt install
pkg update && pkg upgrade
pkg install wget
pkg install ffmpeg
pkg install nodejs
npm i -g cwebp
npm i -g ytdl 
npm i
npm i got
